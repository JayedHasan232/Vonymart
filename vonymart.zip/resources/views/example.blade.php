@extends('layouts.app')

@push('stylesheets')
    
@endpush

@push('scripts')
    
@endpush

@push('meta')
    <title>{{ config('app.name', 'Laravel') }}</title>
@endpush

@push('schema')
    
@endpush

@section('content')
<div class="container-xl">
    
</div>
@endsection
