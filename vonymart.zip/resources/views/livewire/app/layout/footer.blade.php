<section>
    <div class="footer">
        <div class="{{ env('BS_CONTAINER') }}">
            <div class="row align-items-center">
                <div class="col-md-4">Menu</div>
                <div class="col-md-4">Contact Us</div>
                <div class="col-md-4">Get In Touch</div>
            </div>
        </div>
    </div>

    <div class="copyright">
        <div class="{{ env('BS_CONTAINER') }}">
            &copy; {{ date('Y') }} {{ env('APP_NAME') }}. All rights reserved
        </div>
    </div>
</section>